import 'package:flutter/material.dart';
import 'package:pet_adoption/pages/auth_page.dart';

class Router {
  static const String authPage = '/authpage';

  static Route<dynamic> generateRoute(RouteSettings routeSettings){
    switch(routeSettings.name){
      case authPage:
        return MaterialPageRoute(
          settings: RouteSettings(name: authPage),
          builder: (_) => AuthPage()
        );
    }
  }
}