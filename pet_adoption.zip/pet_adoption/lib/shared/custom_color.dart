import 'package:flutter/material.dart';
class CustomColor {
  static const Color  primaryColor = Color.fromRGBO(255, 216, 181, 1);
}