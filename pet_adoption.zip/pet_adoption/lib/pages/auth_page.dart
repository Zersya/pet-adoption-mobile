import 'package:flutter/material.dart';
import 'package:pet_adoption/providers/auth_provider.dart';
import 'package:pet_adoption/shared/custom_color.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class AuthPage extends StatefulWidget {
  @override
  _AuthPageState createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  AuthProvider _authProvider = AuthProvider();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          color: CustomColor.primaryColor,
          child: Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  'images/pet/cat1.png',
                  fit: BoxFit.contain,
                  height: 200.0,
                ),
                SizedBox(height: 50,),
                Text("Pet Adoption",
                  style: Theme.of(context).textTheme.title,),
                Text("Adopt any pet, and give them a good life.",
                  style: Theme.of(context).textTheme.subtitle, textAlign: TextAlign.center,),
                SizedBox(height: 50,),
                Card(
                  color: Colors.white,
                  child: IconButton(
                      icon: Image.asset('images/icons/icons8-google-96.png'),
                      onPressed: () {
                        _authProvider.handleSignIn();
                      }),
                )
              ],
            ),
          )),
    );
  }
}
